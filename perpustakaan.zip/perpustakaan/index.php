<?php

	include_once 'koneksi.php';
	$barang = mysqli_query($koneksi, "SELECT * FROM m_item");
	$banyakbarang = mysqli_num_rows($barang);

	$supplier = mysqli_query($koneksi, "SELECT * FROM m_supplier");
	$banyaksupplier = mysqli_num_rows($supplier);

	$mutasi = mysqli_query($koneksi, "SELECT * FROM m_mutasi");
	$banyakmutasi = mysqli_num_rows($mutasi);


?>
<!DOCTYPE html>
<html>
	<head>
		<title> Perpustakaan Universitas Ahmad Dahlan </title>
		<link rel="stylesheet" href="assets/css/bootstrap.min.css">
		<link rel="stylesheet" href="assets/css/style.css">
		<link rel="stylesheet" href="assets/fonts/css/font-awesome.min.css">
	</head>
	<body>
		<nav class="navbar navbar-expand-lg navbar-light bg-white">
		  	<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar" aria-controls="navbar" aria-expanded="false" aria-label="Toggle navigation">
		    <span class="navbar-toggler-icon"></span>
		  	</button>
		  	<a class="navbar-brand" href="#"><img src="assets/img/trolley.png" alt="" style="max-width: 35px;"></a>
		  	<div class="collapse navbar-collapse" id="navbar">
		    	<ul class="navbar-nav mr-auto mt-2 mt-lg-0">
		      		<li class="nav-item active">
		        		<a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
		      		</li>
		      		<li class="nav-item">
		        		<a class="nav-link" href="supplier.php">Nama Mahasiswa</a>
		      		</li>
		      		<li class="nav-item">
		        		<a class="nav-link" href="barang.php">Daftar Buku</a>
		      		</li>
		      		<li class="nav-item">
		        		<a class="nav-link" href="mutasi.php">Tanggal Kembali</a>
		      		</li>
		    	</ul>
		  	</div>
		</nav>
		<br><br>
		<div class="container">
			<div class="card-group">
			  <div class="card">
			    <img class="card-img-top" src="assets/img/archive.png" alt="Card image cap" style="max-width: 150px; margin: auto; margin-top:20px;">
			    <div class="card-body">
			      <h5 class="card-title" align="center">Buku</h5>
			      <p class="card-text">Menu ini berisi daftar buku dan kode buku. Total buku yang saat ini ada yaitu <b><?php echo $banyakbarang; ?> buku</b></p>
			    </div>
			  </div>
			  <div class="card">
			    <img class="card-img-top" src="assets/img/boy.png" alt="Card image cap" style="max-width: 150px; margin: auto; margin-top:20px;">
			    <div class="card-body">
			      <h5 class="card-title" align="center">Mahasiswa</h5>
			      <p class="card-text">Menu ini berisi daftar nama mahasiswa yang memunjam buku, kotak serta alamat. Banyak mahasiswa yang sudah meminjam buku yaitu <b><?php echo $banyaksupplier; ?> mahasiswa</b></p>
			    </div>
			  </div>
			  <div class="card">
			    <img class="card-img-top" src="assets/img/trolley2.png" alt="Card image cap" style="max-width: 150px; margin: auto; margin-top:20px;">
			    <div class="card-body">
			      <h5 class="card-title" align="center">Tanggal Kembali</h5>
			      <p class="card-text">Menu ini adalah menu dimana data pengembalian buku dicatat. Total buku yang sudah dikembalikan yaitu <b><?php echo $banyakmutasi; ?> buah buku</b></p>
			    </div>
			  </div>
			</div>
		</div>
		
		<div class="container-fluid  fixed-bottom bg-light" style=" color: #999;">
			<div class="row">
				<div class="col-sm-12">
					<p align="center">&copy; Christ Memory</p>
				</div>
			</div>
		</div>


		
		<script src="assets/js/jquery.js"></script>
		<script src="assets/js/popper.js"></script>
		<script src="assets/js/script.js"></script>
		<script src="assets/js/bootstrap.min.js"></script>
	</body>
</html>