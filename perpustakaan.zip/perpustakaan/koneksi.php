<?php


	$db 	= 'sp_stockgudang';
	$host 	= 'localhost';
	$pass 	= '';
	$user 	= 'root';

	$koneksi = mysqli_connect($host,$user,$pass,$db);


?>